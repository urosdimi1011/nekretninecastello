@extends('layouts.user')

@section('title', 'CASTELLO NEKRETNINE VRŠAC -'.$nekretnina->naziv)
@section('description', $nekretnina->opis)
@section('keywords', 'nekretnine,vrsac,kupi')
@section('content')

    <div class="slika-nekretnine-pozadina">
        <div class="container p-200 pb-5 naslov">

            <div class="block-nekretnine jedna-nekretnina">

                <div class="header-block-nekretnina efekat-box-shadow mt-5 pb-5">
                   <div class="nekeretnina-glavna">
                       <div class="col-12 col-md-12 col-lg-6 content-block-nekretnina mb-5">
                           <div class="slider-nekretnine">
                               <section
                                   class="splide nekretnina-slider h-100">
                                   <div class="splide__track">
                                       <ul class="splide__list my-gallery">
                                           @foreach($nekretnina->slike as $a)

                                               <li class="splide__slide nekretnina-slika"
                                               >
                                                   <a data-pswp-src="{{asset("assets/img/".$a->putanja)}}">

                                                       <img src="{{asset("assets/img/".$a->putanja)}}" alt="{{$a->alt}}">

                                                   </a>
                                               </li>

                                           @endforeach
                                       </ul>
                                   </div>

                                   <section class="splide thumbnail-carousel odmakni">
                                       <div class="splide__track">
                                           <ul class="splide__list">
                                               @foreach($nekretnina->slike as $a)

                                                   <li class="splide__slide male-slike-slider">
                                                       <img src="{{asset("assets/img/".$a->putanja)}}" alt="{{$a->alt}}">
                                                   </li>

                                               @endforeach
                                           </ul>
                                       </div>
                                   </section>

                               </section>
                           </div>


                           <div class="dodatne-informacije bg-white efekat-box-shadow mt-5">
                               <div class="naslov-dodane-informacije mb-4">
                                   <h3><i class="fa-solid fa-circle-info"></i> Dodatne informacije</h3>
                               </div>
                               <div class="informacije pb-4 mt-4">
                                   <ul class="flex-list p-0">
                                       @forelse($nekretnina->a as $svojstvo)
                                           <li>
                                               <i class="{{$svojstvo->klasaIkonice}}"></i><br/> <span class="bold-moj">{{$svojstvo->atribut}}</span> <br/> {{$svojstvo->vrednost}} {!! $svojstvo->atribut == "Kvadratura" ? "m"."<sup>2</sup>" : "" !!}
                                           </li>
                                       @empty
                                           <p>Nema</p>
                                       @endforelse
                                   </ul>
                               </div>

                           </div>
                       </div>
                       <div class="col-12 col-md-12 col-lg-5 mb-5">
                           <span class="naslov-nekretnine">Castello nekretnina</span>
                           <h1 class="text-naslov">{{$nekretnina->naziv}}</h1>
                           <span class="cena"><span class="konkretna-cena">{{ number_format($nekretnina->cena, 0, ',', '.') }}</span>&euro;@if($nekretnina->cena_metar!=null && $nekretnina->cena_metar == 1)/m<sup>2</sup>@endif</span>
                            <p class="text-opis">{{$nekretnina->opis}}</p>
                       </div>
                   </div>
                </div>

            </div>

{{--            <div class="row">--}}
{{--                <div class="header-block-nekretnina efekat-box-shadow mt-5 mb-5 bg-white">--}}
{{--                    <h1 class="p-3">{{$nekretnina->naziv}}</h1>--}}

{{--                    <span class="cena"><span class="konkretna-cena">{{ number_format($nekretnina->cena, 0, ',', '.') }}</span>&euro;@if($nekretnina->cena_metar!=null && $nekretnina->cena_metar == 1)/m<sup>2</sup>@endif</span>--}}

{{--                </div>--}}
{{--            </div>--}}
{{--            <div class="container">--}}
{{--                <div class="row justify-content-between jedna-nekretnina">--}}

{{--                    <div class="col-6 content-block-nekretnina mb-5">--}}
{{--                        <div class="slider-nekretnine">--}}
{{--                            <section--}}
{{--                                class="splide nekretnina-slider h-100">--}}
{{--                                <div class="splide__track">--}}
{{--                                    <ul class="splide__list my-gallery">--}}
{{--                                        <li class="splide__slide nekretnina-slika"--}}
{{--                                        >--}}
{{--                                            <a data-pswp-src="{{asset("assets/img/".$nekretnina->slika->putanja)}}">--}}

{{--                                                <img src="{{asset("assets/img/".$nekretnina->slika->putanja)}}" alt="{{$nekretnina->slika->alt}}">--}}

{{--                                            </a>--}}
{{--                                        </li>--}}
{{--                                        @foreach($nekretnina->slike as $a)--}}

{{--                                            <li class="splide__slide nekretnina-slika"--}}
{{--                                            >--}}
{{--                                                <a data-pswp-src="{{asset("assets/img/".$a->putanja)}}">--}}

{{--                                                    <img src="{{asset("assets/img/".$a->putanja)}}" alt="{{$a->alt}}">--}}

{{--                                                </a>--}}
{{--                                            </li>--}}

{{--                                        @endforeach--}}
{{--                                    </ul>--}}
{{--                                </div>--}}

{{--                                <section class="splide thumbnail-carousel odmakni">--}}
{{--                                    <div class="splide__track">--}}
{{--                                        <ul class="splide__list">--}}
{{--                                            <li class="splide__slide male-slike-slider">--}}
{{--                                                <img src="{{asset("assets/img/".$nekretnina->slika->putanja)}}" alt="{{$nekretnina->slika->alt}}">--}}
{{--                                            </li>--}}
{{--                                            @foreach($nekretnina->slike as $a)--}}

{{--                                                <li class="splide__slide male-slike-slider">--}}
{{--                                                    <img src="{{asset("assets/img/".$a->putanja)}}" alt="{{$a->alt}}">--}}
{{--                                                </li>--}}

{{--                                            @endforeach--}}
{{--                                        </ul>--}}
{{--                                    </div>--}}
{{--                                </section>--}}

{{--                            </section>--}}
{{--                        </div>--}}


{{--                        <div class="dodatne-informacije bg-white efekat-box-shadow mt-5">--}}
{{--                            <div class="naslov-dodane-informacije mb-4">--}}
{{--                                <h3><i class="fa-solid fa-circle-info"></i> Dodatne informacije</h3>--}}
{{--                            </div>--}}
{{--                            <div class="informacije pb-4 mt-4">--}}
{{--                                <ul class="flex-list p-0">--}}
{{--                                    @forelse($nekretnina->a as $svojstvo)--}}
{{--                                        <li>--}}
{{--                                            <i class="{{$svojstvo->klasaIkonice}}"></i><br/> <span class="bold-moj">{{$svojstvo->atribut}}</span> <br/> {{$svojstvo->vrednost}} {!! $svojstvo->atribut == "Kvadratura" ? "m"."<sup>2</sup>" : "" !!}--}}
{{--                                        </li>--}}
{{--                                    @empty--}}
{{--                                        <p>Nema</p>--}}
{{--                                    @endforelse--}}
{{--                                </ul>--}}
{{--                            </div>--}}

{{--                        </div>--}}
{{--                    </div>--}}
{{--                    <div class="col-5 mb-5">--}}
{{--                        <div class="blok-za-opis bg-white efekat-box-shadow">--}}
{{--                            <div class="naslov-dodane-informacije ">--}}
{{--                                <h3>Opis</h3>--}}
{{--                            </div>--}}
{{--                            <div class="opis-block response-p bg-white p-4">--}}
{{--                                <p>{{$nekretnina->opis}}</p>--}}
{{--                            </div>--}}
{{--                            <div class="button-kontakt p-4">--}}
{{--                                <a class="telefon-button" href="tel:381 65 823 4501">--}}
{{--                                    <div class="bt_bb_service_content d-flex mojee">--}}
{{--                                        <i class="fa-solid fa-mobile"></i>--}}
{{--                                        <div class="container-content">--}}
{{--                                            <div class="bt_bb_service_content_supertitle">POZOVITE ODMAH</div>--}}
{{--                                            <div class="bt_bb_service_content_title">+381 65 823 4501</div>--}}
{{--                                        </div>--}}
{{--                                    </div>--}}
{{--                                </a>--}}
{{--                            </div>--}}
{{--                        </div>--}}
{{--                    </div>--}}

{{--                    @if($nekretnina->link_ka_videu !== null)--}}
{{--                        <div class="video-blok">--}}
{{--                            <iframe src="{{$nekretnina->link_ka_videu}}" title="YouTube video player"  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen>--}}

{{--                            </iframe>--}}
{{--                        </div>--}}
{{--                    @endif--}}


{{--                    @if($nekretnina->link_ka_videu_virtual !== null)--}}
{{--                        <div class="video-blok">--}}
{{--                            <iframe src="{{$nekretnina->link_ka_videu_virtual}}" title="YouTube video player"  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen>--}}

{{--                            </iframe>--}}
{{--                        </div>--}}
{{--                    @endif--}}

{{--                </div>--}}
{{--            </div>--}}


{{--                                @if($nekretnina->link_ka_videu !== null)--}}
{{--                                    <div class="video-blok">--}}
{{--                                        <iframe src="{{$nekretnina->link_ka_videu}}" title="YouTube video player"  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen>--}}

{{--                                        </iframe>--}}
{{--                                    </div>--}}
{{--                                @endif--}}


{{--                                @if($nekretnina->link_ka_videu_virtual !== null)--}}
{{--                                    <div class="video-blok">--}}
{{--                                        <iframe src="{{$nekretnina->link_ka_videu_virtual}}" title="YouTube video player"  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen>--}}

{{--                                        </iframe>--}}
{{--                                    </div>--}}
{{--                                @endif--}}
        </div>
    </div>
@endsection
